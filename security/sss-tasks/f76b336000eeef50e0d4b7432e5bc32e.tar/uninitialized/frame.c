
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

int verify(char *str)
{
	char buf[] = "Where is the flag?";
	int n;

	return strncmp(buf, str, strlen(buf + n)) == 0;
}

void foo()
{
	char buf[1024];
	char num[4];
	unsigned int n;

	fgets(num, 4, stdin);
	n = atoi(num);

	fgets(buf + n, 16, stdin);

	if (verify(buf)) {
		FILE *f = fopen("/flag", "r");
		char flag[32];

		fscanf(f, "%s", flag);
		printf("%s\n", flag);
		fclose(f);
	}
}

int main(void)
{
	foo();

	return 0;
}
