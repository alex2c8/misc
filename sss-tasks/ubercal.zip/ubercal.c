#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>

#define HIBER 16
int allowed_day = 0;
int entry = 0;

void no_chance()
{
	printf("No chance to get here\n");
	printf("But let's write it on the Wall of Fame just in case\n");
	system("date >> /tmp/wall_of_fame2.txt");
}


void process_calendar(int *calendar)
{
	/* TODO */
	sleep(HIBER);
}

void ubercal()
{
	int i, calendar[HIBER];

	char name[100];
	puts("Enter your name:\n");
	scanf("%99s", name);

	for (i = 0 ; i < HIBER; i++)
		calendar[i] = 42;

	if (allowed_day == 0) {
		printf("You are allowed to write an entry in the %d-day hibernation calendar. What will it be? Make it a good one!\n", HIBER);

		puts("Which day?");
		scanf("%d", &allowed_day);

		puts("What do you want to write?");
		scanf("%d", &entry);
	} else {
		puts("You already wrote in my calendar");
	}
	calendar[allowed_day] = entry;

	process_calendar(calendar);

	puts("Goodbye");
	puts(name);
}


void doprocessing(int sockfd)
{
	dup2(sockfd, 1);
	dup2(sockfd, 0);
	setbuf(stdout, NULL);
	ubercal();
}

int main(int argc, char **argv)
{
    int optval = 1;
    int sockfd, newsockfd, portno;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;

    if (argc != 2) {
	printf("Usage: %s <port>\n", argv[0]);
	exit(0);
    }

    portno = atoi(argv[1]);


    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("ERROR opening socket");
        exit(1);
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;

    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(portno);
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
         perror("ERROR on binding");
         exit(1);
    }

    listen(sockfd, 5);
    clilen = sizeof(cli_addr);
    while (1)
    {
	int pid;
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0)
        {
            perror("ERROR on accept");
            exit(1);
        }
        pid = fork();
        if (pid < 0)
        {
            perror("ERROR on fork");
	    exit(1);
        }
        if (pid == 0)
        {

            close(sockfd);
            doprocessing(newsockfd);
            exit(0);
        }
        else
        {
            close(newsockfd);
        }
    }
}
